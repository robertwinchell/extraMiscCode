class MyTestClass:
	pass
