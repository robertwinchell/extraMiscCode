import TestPackage.TestClass

class MyClass(TestPackage.TestClass.MyTestClass):
	pass
